[실행 방법]
1) Node.js 18 이상 설치 후, 이 폴더에서  node server.js  실행
2) 브라우저에서 http://localhost:3000 접속 (index.html = 로그인 화면으로 시작)
   - 공지사항·군산대 신문이 학교 사이트에서 실시간(5분 캐시)으로 표시됩니다.
   - index.html / main.html을 파일로 직접 열면 서버가 없어 저장된 목록(기준 날짜 표시)이 보입니다.

[폴더]
index.html(로그인), main.html(메인)   화면 뼈대 (main.html은 약 5.9KB)
css/style.css            스타일 전체 (!important 없음)
js/data.js               서비스·통합정보 메뉴·식단·시간표 데이터
js/script.js             화면 동작 (서비스 목록·빠른 정보·통합정보·식단·설정)
js/live.js               실시간 공지·신문·eclass 과제·빠른 정보
js/account.js, extra.js, login.js
server.js                공지·신문을 대신 가져오는 서버, img/

[v4 변경 내용]
- 반응형 제거: 미디어쿼리를 모두 없애고 모바일 화면 기준(최대 30rem, 가운데 정렬) 한 가지로 통일
- (모)통합정보: 다른 대학 모바일 포털(분야별 묶음·전체 메뉴·검색·즐겨찾기·메뉴 개인화) 구성을 참고해 개편
  · 19개 분야·82개 세부 메뉴를 한 화면 흐름에서 모두 표시 (기본은 접힘, 분야를 눌러 펼침)
  · 세부 메뉴를 누르면 팝업이 열림 (공식 통합정보시스템 링크 포함)
  · 상단 분야 칩을 누르면 해당 분야로 이동, 스크롤하면 현재 분야가 표시됨
  · 전체 검색(이름·분야), 즐겨찾기 탭, 최근 사용 탭, "모두 접기/펼치기"
  · 별을 눌러도 펼침 상태와 스크롤 위치가 유지됨
- 신문 썸네일을 불러오지 못하면 이미지만 숨김

[v3 변경 내용]
- HTML 축소: 서비스 아이콘·설정 목록·통합정보 탭 등 반복 마크업을 js/data.js 데이터로 만들어 JS가 그림 (22.7KB → 5.9KB)
- 기초웹 프로그래밍 1~8주차 교안 규칙 적용
  · 1~4주차: <!doctype html>·lang="ko"·charset·viewport·description, header/nav/main/section/footer 구조,
    제목 계층 h1→h2(건너뜀 없음), 모든 img에 alt, 폼 label for/id 연결,
    div role="button" 대신 네이티브 button(순서 이동 손잡이 포함), 팝업은 native <dialog>
  · 5~6주차: 외부 CSS 한 파일, :root 변수, * { box-sizing: border-box }, 글자·여백은 rem, !important 사용 안 함
  · 7~8주차: sticky 헤더/하단 메뉴, Flexbox(메뉴·카드 내부) + Grid(서비스·카드·통합정보 목록),
    모바일 기준 화면, :focus-visible 윤곽선
- 군산대 신문 서비스를 누르면 신문 사이트(press.kunsan.ac.kr)가 열립니다.
- 식단의 "자동" 버튼 글자를 "기본으로 / 기본 표시 중"으로 바꿨습니다(기본 식당은 교직원).

[참고]
- 공지사항 게시판을 "일반 공지"로 바꾸려면 server.js의 NOTICE_URL boardId를 BBS_0000008로 바꾸세요.
- eclass 남은 과제는 로그인이 필요해 예시 데이터입니다.

[v5 변경 내용]
- GitHub Pages 공개·Supabase 로그인 연결 준비 (GITHUB_SUPABASE.txt 참고)
  js/config.js(Supabase 값), js/auth.js(클라이언트), supabase/profiles.sql(RLS 포함 표 생성 SQL)
  login.html: 설정이 있으면 전자우편 로그인 + 회원가입 표시, 없으면 예시 로그인 유지

[v6 변경 내용]
- index.html = 로그인 화면, main.html = 메인 화면 (로그인 성공 시 main.html 로 이동)
- 학번으로 로그인하면 js/students.js 표의 이름이 표시됩니다. 표에 없는 학번은 처음 한 번 이름을 입력받아 그 브라우저에 기억합니다.
- GitHub 다시 올리기: git add -A / git commit -m "index를 로그인 화면으로 변경" / git push
